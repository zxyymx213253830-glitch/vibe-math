Lean source and evidence accompany main.tex. The code ZIP preserves the original repository paths. TeX is only at the submission root.
Code ZIP SHA256: 2f1dfc2b60ac91c96ab15d24bc69a1cfe96da8efd366d10d191232726083c83b
Author: ZHOU XINGYUAN. This local package is not submitted. Release rights/license and human mathematical signoff remain the author's responsibility.
